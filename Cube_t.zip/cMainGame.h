#pragma once

#include "cVector3.h"
#include "cMatrix.h"

class cMainGame
{
public:
	cMainGame();
	~cMainGame();

private:
	HDC m_memDC;
	HBITMAP m_hOldBitmap, m_hBitmap;

	std::vector<cVector3> m_vecVertex;
	std::vector<DWORD> m_vecIndex;
	std::vector<cVector3> m_vecLineVertex;

	cMatrix m_matWorld;
	cMatrix m_matView;
	cMatrix m_matProj;
	cMatrix m_matViewport;

	cVector3 m_vEye;
	cVector3 m_vLookAt;
	cVector3 m_vUp;

	float m_x;
	float m_y;
	float m_z;

public:
	void Setup();
	void Update();
	void Render(HDC hdc);
	void WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
};

